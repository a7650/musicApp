<template>
  <div class="xxx">
    base
  </div>
</template>

<script>
export default {
  name: 'xxx',
  props: {
    
  },

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less" rel="stylesheet/stylus">


</style>
