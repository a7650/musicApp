<template>
    <div class="radio">
        radiolist
    </div>
</template>


<script>
export default {
    created(){
        alert("radio created");
    }
}
</script>
